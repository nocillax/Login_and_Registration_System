﻿CREATE TABLE Users (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50),
    LastName NVARCHAR(50),
    Username NVARCHAR(50) UNIQUE,
    Password NVARCHAR(255),
    UserRole NVARCHAR(20) CHECK (UserRole IN ('Admin', 'User')) DEFAULT User
);
﻿namespace Login_System
{
    partial class usrDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(usrDashboard));
            uc_usrdashboardPanel = new Panel();
            label2 = new Label();
            exitbtn = new PictureBox();
            UpdtLabel = new Label();
            UpdateLabel = new PictureBox();
            sideBar = new PictureBox();
            LogOutLbl = new Label();
            LogOutpic = new PictureBox();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            uc_usrdashboardPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)exitbtn).BeginInit();
            ((System.ComponentModel.ISupportInitialize)UpdateLabel).BeginInit();
            ((System.ComponentModel.ISupportInitialize)sideBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)LogOutpic).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // uc_usrdashboardPanel
            // 
            uc_usrdashboardPanel.Controls.Add(label2);
            uc_usrdashboardPanel.Controls.Add(exitbtn);
            uc_usrdashboardPanel.Location = new Point(79, 0);
            uc_usrdashboardPanel.Name = "uc_usrdashboardPanel";
            uc_usrdashboardPanel.Size = new Size(821, 580);
            uc_usrdashboardPanel.TabIndex = 16;
            uc_usrdashboardPanel.Paint += uc_usrdashboardPanel_Paint;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Perpetua Titling MT", 36F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point);
            label2.ForeColor = Color.DarkSlateGray;
            label2.Location = new Point(145, 249);
            label2.Name = "label2";
            label2.Size = new Size(509, 58);
            label2.TabIndex = 21;
            label2.Text = "USER DASHBOARD";
            // 
            // exitbtn
            // 
            exitbtn.Cursor = Cursors.Hand;
            exitbtn.Image = (Image)resources.GetObject("exitbtn.Image");
            exitbtn.Location = new Point(793, 3);
            exitbtn.Name = "exitbtn";
            exitbtn.Size = new Size(25, 24);
            exitbtn.SizeMode = PictureBoxSizeMode.Zoom;
            exitbtn.TabIndex = 20;
            exitbtn.TabStop = false;
            exitbtn.Click += exitbtn_Click;
            // 
            // UpdtLabel
            // 
            UpdtLabel.AutoSize = true;
            UpdtLabel.BackColor = Color.LightSteelBlue;
            UpdtLabel.Cursor = Cursors.Hand;
            UpdtLabel.FlatStyle = FlatStyle.Flat;
            UpdtLabel.Font = new Font("Perpetua Titling MT", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            UpdtLabel.ForeColor = Color.Black;
            UpdtLabel.Location = new Point(9, 159);
            UpdtLabel.Name = "UpdtLabel";
            UpdtLabel.Size = new Size(64, 16);
            UpdtLabel.TabIndex = 19;
            UpdtLabel.Text = "Update";
            UpdtLabel.Click += UpdtLabel_Click;
            // 
            // UpdateLabel
            // 
            UpdateLabel.BackColor = Color.LightSteelBlue;
            UpdateLabel.Cursor = Cursors.Hand;
            UpdateLabel.Image = (Image)resources.GetObject("UpdateLabel.Image");
            UpdateLabel.Location = new Point(24, 121);
            UpdateLabel.Margin = new Padding(3, 4, 3, 4);
            UpdateLabel.Name = "UpdateLabel";
            UpdateLabel.Size = new Size(30, 30);
            UpdateLabel.SizeMode = PictureBoxSizeMode.Zoom;
            UpdateLabel.TabIndex = 15;
            UpdateLabel.TabStop = false;
            UpdateLabel.Click += UpdateLabel_Click;
            // 
            // sideBar
            // 
            sideBar.BackColor = Color.LightSteelBlue;
            sideBar.Location = new Point(0, 0);
            sideBar.Margin = new Padding(3, 4, 3, 4);
            sideBar.Name = "sideBar";
            sideBar.Size = new Size(79, 580);
            sideBar.TabIndex = 14;
            sideBar.TabStop = false;
            // 
            // LogOutLbl
            // 
            LogOutLbl.AutoSize = true;
            LogOutLbl.BackColor = Color.LightSteelBlue;
            LogOutLbl.Cursor = Cursors.Hand;
            LogOutLbl.FlatStyle = FlatStyle.Flat;
            LogOutLbl.Font = new Font("Perpetua Titling MT", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            LogOutLbl.ForeColor = Color.Black;
            LogOutLbl.Location = new Point(5, 486);
            LogOutLbl.Name = "LogOutLbl";
            LogOutLbl.Size = new Size(71, 16);
            LogOutLbl.TabIndex = 22;
            LogOutLbl.Text = "Log Out";
            // 
            // LogOutpic
            // 
            LogOutpic.BackColor = Color.LightSteelBlue;
            LogOutpic.Cursor = Cursors.Hand;
            LogOutpic.Image = (Image)resources.GetObject("LogOutpic.Image");
            LogOutpic.Location = new Point(24, 448);
            LogOutpic.Margin = new Padding(3, 4, 3, 4);
            LogOutpic.Name = "LogOutpic";
            LogOutpic.Size = new Size(30, 30);
            LogOutpic.SizeMode = PictureBoxSizeMode.Zoom;
            LogOutpic.TabIndex = 21;
            LogOutpic.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.LightSteelBlue;
            label1.Cursor = Cursors.Hand;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Perpetua Titling MT", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(4, 415);
            label1.Name = "label1";
            label1.Size = new Size(71, 16);
            label1.TabIndex = 24;
            label1.Text = "Log Out";
            label1.Click += label1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.LightSteelBlue;
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(24, 377);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(30, 30);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 23;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // usrDashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(900, 580);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Controls.Add(uc_usrdashboardPanel);
            Controls.Add(UpdtLabel);
            Controls.Add(UpdateLabel);
            Controls.Add(sideBar);
            Controls.Add(LogOutLbl);
            Controls.Add(LogOutpic);
            Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.None;
            Name = "usrDashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "usrDashboard";
            uc_usrdashboardPanel.ResumeLayout(false);
            uc_usrdashboardPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)exitbtn).EndInit();
            ((System.ComponentModel.ISupportInitialize)UpdateLabel).EndInit();
            ((System.ComponentModel.ISupportInitialize)sideBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)LogOutpic).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel uc_usrdashboardPanel;
        private PictureBox exitbtn;
        private Label UpdtLabel;
        private PictureBox UpdateLabel;
        private PictureBox sideBar;
        private Label LogOutLbl;
        private PictureBox LogOutpic;
        private Label label1;
        private PictureBox pictureBox1;
        private Label label2;
    }
}
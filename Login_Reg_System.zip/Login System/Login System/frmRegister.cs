using System.Drawing.Imaging;
using System.Windows.Forms;
using System.Data.SqlClient;




namespace Login_System
{
    public partial class frmRegister : Form
    {
        string connectionString = @"Data Source=DESKTOP-H9MPPVO\SQLEXPRESS;Initial Catalog=UserRegistrationDB;Integrated Security=True;Encrypt=False;";

        public frmRegister()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
        private void label5_Click_1(object sender, EventArgs e)
        {
            new frmLogin().Show();
            this.Hide();
        }

        private void Register_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "" || txtPassword.Text == "" || txtComPassword.Text == "" || txtEmail.Text == "")
            {
                MessageBox.Show("No field can be empty", "Registration Failed!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txtPassword.Text == txtComPassword.Text)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Check if the username already exists
                    string checkUsernameQuery = "SELECT COUNT(*) FROM Users WHERE Username = @Username";

                    using (SqlCommand checkUsernameCommand = new SqlCommand(checkUsernameQuery, connection))
                    {
                        checkUsernameCommand.Parameters.AddWithValue("@Username", txtUsername.Text);

                        int existingUserCount = (int)checkUsernameCommand.ExecuteScalar();

                        if (existingUserCount > 0)
                        {
                            // Username already exists
                            MessageBox.Show("Username already exists. Please choose a different username.", "Registration Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    // Insert the user data into the Users table
                    string insertQuery = "INSERT INTO Users (FirstName, LastName, Username, Password, Email, UserRole) VALUES (@FirstName, @LastName, @Username, @Password, @Email, @UserRole)";

                    using (SqlCommand insertCommand = new SqlCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                        insertCommand.Parameters.AddWithValue("@LastName", txtLastName.Text);
                        insertCommand.Parameters.AddWithValue("@Username", txtUsername.Text);
                        insertCommand.Parameters.AddWithValue("@Password", txtPassword.Text);
                        insertCommand.Parameters.AddWithValue("@Email", txtEmail.Text);
                        insertCommand.Parameters.AddWithValue("@UserRole", "User");

                        insertCommand.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Your account has been created successfully", "Registration Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Clear the textboxes
                txtFirstName.Text = "";
                txtLastName.Text = "";
                txtUsername.Text = "";
                txtPassword.Text = "";
                txtComPassword.Text = "";
                txtEmail.Text = "";
            }
            else
            {
                MessageBox.Show("Passwords do not match, Please enter password again", "Registration Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Text = "";
                txtComPassword.Text = "";
            }
        }

        private void checkbxShowPas_CheckedChanged(object sender, EventArgs e)
        {
            if (checkbxShowPas.Checked)
            {
                txtPassword.PasswordChar = '\0';
                txtComPassword.PasswordChar = '\0';
            }
            else
            {
                txtPassword.PasswordChar = '�';
                txtComPassword.PasswordChar = '�';
            }
        }

        private void frmRegister_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click_2(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
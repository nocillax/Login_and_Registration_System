﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Login_System
{
    public partial class uc_updateProfile : UserControl
    {
        public uc_updateProfile()
        {
            InitializeComponent();
        }


        private void dashUpdtFirstName_TextChanged(object sender, EventArgs e)
        {

        }

        private void dashUpdtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void dashUpdtLastName_TextChanged(object sender, EventArgs e)
        {

        }

        private void dashUpdtReligion_TextChanged(object sender, EventArgs e)
        {
        }


        private void dashUpdtNationality_TextChanged(object sender, EventArgs e)
        {
        }

        private void dashUpdtMaritalStatus_TextChanged(object sender, EventArgs e)
        {
        }

        private void dashUpdtPhoneNumber_TextChanged(object sender, EventArgs e)
        {
        }

        private void dashUpdtEmail_TextChanged(object sender, EventArgs e)
        {
        }

        private void dashUpdtUniversity_TextChanged(object sender, EventArgs e)
        {
        }

        private void uc_updateProfile_Load(object sender, EventArgs e)
        {
        }

        private int GetUserID(string username)
        {
            try
            {
                string connectionString = @"Data Source=DESKTOP-H9MPPVO\SQLEXPRESS;Initial Catalog=UserRegistrationDB;Integrated Security=True;Encrypt=False;";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string getUserIDQuery = @"SELECT UserID FROM Users WHERE Username = @Username";

                    using (SqlCommand getUserIDCommand = new SqlCommand(getUserIDQuery, connection))
                    {
                        getUserIDCommand.Parameters.AddWithValue("@Username", username);

                        object result = getUserIDCommand.ExecuteScalar();

                        if (result != null)
                        {
                            return Convert.ToInt32(result);
                        }
                        else
                        {
                            return -1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while retrieving the user ID: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
        }

        private bool IsUsernameAvailable(string username)
        {
            try
            {
                string connectionString = @"Data Source=DESKTOP-H9MPPVO\SQLEXPRESS;Initial Catalog=UserRegistrationDB;Integrated Security=True;Encrypt=False;";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string checkUsernameQuery = @"SELECT COUNT(*) FROM Users WHERE Username = @Username";

                    using (SqlCommand checkUsernameCommand = new SqlCommand(checkUsernameQuery, connection))
                    {
                        checkUsernameCommand.Parameters.AddWithValue("@Username", username);

                        int existingUserCount = (int)checkUsernameCommand.ExecuteScalar();

                        return existingUserCount > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while checking the username: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }


        private void UpdateUserProfile(string targetUsername, string username, string firstName, string lastName, string phoneNumber, string religion, string nationality, string maritalStatus, string email)
        {
            try
            {
                string connectionString = @"Data Source=DESKTOP-H9MPPVO\SQLEXPRESS;Initial Catalog=UserRegistrationDB;Integrated Security=True;Encrypt=False;";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Check if the updated username is already in use

                    if (IsUsernameAvailable(targetUsername))
                    {
                        int userID = GetUserID(targetUsername);

                        string updateQuery = @"UPDATE Users 
                                       SET Username = @Username,
                                           FirstName = @FirstName, 
                                           LastName = @LastName, 
                                           PhoneNumber = @PhoneNumber, 
                                           Religion = @Religion, 
                                           Nationality = @Nationality, 
                                           MaritalStatus = @MaritalStatus, 
                                           Email = @Email
                                       WHERE UserID = @UserID";

                        using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                        {
                            updateCommand.Parameters.AddWithValue("@UserID", userID);
                            updateCommand.Parameters.AddWithValue("@Username", username);
                            updateCommand.Parameters.AddWithValue("@FirstName", firstName);
                            updateCommand.Parameters.AddWithValue("@LastName", lastName);
                            updateCommand.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                            updateCommand.Parameters.AddWithValue("@Religion", religion);
                            updateCommand.Parameters.AddWithValue("@Nationality", nationality);
                            updateCommand.Parameters.AddWithValue("@MaritalStatus", maritalStatus);
                            updateCommand.Parameters.AddWithValue("@Email", email);
                            

                            try
                            {
                                int rowsAffected = updateCommand.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Profile updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                else
                                {
                                    MessageBox.Show("Failed to update profile. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                            catch (SqlException ex)
                            {
                                if (ex.Number == 2627) // Unique constraint violation error number
                                {
                                    MessageBox.Show("The provided username is already in use. Please choose a different username.",
                                        "Username In Use", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                                else
                                {
                                    MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Username not found. Please enter a valid username.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void dashUpdtSubmit_Click_1(object sender, EventArgs e)
        {
            // Get the data from the form
            string targetUsername = targetUser.Text;
            string updatedUsername = dashUpdtUsername.Text;
            string updatedFirstName = dashUpdtFirstName.Text;
            string updatedLastName = dashUpdtLastName.Text;
            string updatedPhoneNumber = dashUpdtPhoneNumber.Text;
            string updatedReligion = dashUpdtReligion.Text;
            string updatedNationality = dashUpdtNationality.Text;
            string updatedMaritalStatus = dashUpdtMaritalStatus.Text;
            string updatedEmail = dashUpdtEmail.Text;
            

            // Update the user's profile in the database
            UpdateUserProfile(targetUsername, updatedUsername, updatedFirstName, updatedLastName, updatedPhoneNumber, updatedReligion, updatedNationality, updatedMaritalStatus, updatedEmail);

            // Clear the textboxes
            targetUser.Text = "";
            dashUpdtUsername.Text = "";
            dashUpdtFirstName.Text = "";
            dashUpdtLastName.Text = "";
            dashUpdtPhoneNumber.Text = "";
            dashUpdtReligion.Text = "";
            dashUpdtNationality.Text = "";
            dashUpdtMaritalStatus.Text = "";
            dashUpdtEmail.Text = "";
            dashUpdtUniversity.Text = "";
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void targetUser_TextChanged(object sender, EventArgs e)
        {

        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

﻿namespace Login_System
{
    partial class uc_updateProfile
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_updateProfile));
            label1 = new Label();
            dashUpdtFirstName = new TextBox();
            label2 = new Label();
            dashUpdtUsername = new TextBox();
            lbl4 = new Label();
            dashUpdtPhoneNumber = new TextBox();
            lbl6 = new Label();
            dashUpdtNationality = new TextBox();
            lbl7 = new Label();
            dashUpdtMaritalStatus = new TextBox();
            label3 = new Label();
            dashUpdtLastName = new TextBox();
            label4 = new Label();
            label5 = new Label();
            dashUpdtUniversity = new TextBox();
            dashUpdtEmail = new TextBox();
            lbl3 = new Label();
            dashUpdtSubmit = new Button();
            label7 = new Label();
            dashUpdtReligion = new TextBox();
            label6 = new Label();
            targetUser = new TextBox();
            exitbtn = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)exitbtn).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.DarkSlateGray;
            label1.Location = new Point(74, 271);
            label1.Name = "label1";
            label1.Size = new Size(83, 17);
            label1.TabIndex = 6;
            label1.Text = "First Name :";
            label1.TextAlign = ContentAlignment.MiddleRight;
            // 
            // dashUpdtFirstName
            // 
            dashUpdtFirstName.BackColor = Color.FromArgb(230, 231, 233);
            dashUpdtFirstName.BorderStyle = BorderStyle.None;
            dashUpdtFirstName.Location = new Point(158, 269);
            dashUpdtFirstName.Margin = new Padding(3, 4, 3, 4);
            dashUpdtFirstName.Name = "dashUpdtFirstName";
            dashUpdtFirstName.Size = new Size(216, 20);
            dashUpdtFirstName.TabIndex = 7;
            dashUpdtFirstName.TextChanged += dashUpdtFirstName_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.DarkSlateGray;
            label2.Location = new Point(49, 221);
            label2.Name = "label2";
            label2.RightToLeft = RightToLeft.No;
            label2.Size = new Size(108, 17);
            label2.TabIndex = 6;
            label2.Text = "New Username :";
            label2.TextAlign = ContentAlignment.MiddleRight;
            // 
            // dashUpdtUsername
            // 
            dashUpdtUsername.BackColor = Color.FromArgb(230, 231, 233);
            dashUpdtUsername.BorderStyle = BorderStyle.None;
            dashUpdtUsername.Location = new Point(158, 220);
            dashUpdtUsername.Margin = new Padding(3, 4, 3, 4);
            dashUpdtUsername.Name = "dashUpdtUsername";
            dashUpdtUsername.Size = new Size(216, 20);
            dashUpdtUsername.TabIndex = 7;
            dashUpdtUsername.TextChanged += dashUpdtUsername_TextChanged;
            // 
            // lbl4
            // 
            lbl4.AutoSize = true;
            lbl4.FlatStyle = FlatStyle.Flat;
            lbl4.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbl4.ForeColor = Color.DarkSlateGray;
            lbl4.Location = new Point(47, 380);
            lbl4.Name = "lbl4";
            lbl4.RightToLeft = RightToLeft.No;
            lbl4.Size = new Size(109, 17);
            lbl4.TabIndex = 6;
            lbl4.Text = "Phone Number :";
            lbl4.TextAlign = ContentAlignment.MiddleRight;
            // 
            // dashUpdtPhoneNumber
            // 
            dashUpdtPhoneNumber.BackColor = Color.FromArgb(230, 231, 233);
            dashUpdtPhoneNumber.BorderStyle = BorderStyle.None;
            dashUpdtPhoneNumber.Location = new Point(158, 379);
            dashUpdtPhoneNumber.Margin = new Padding(3, 4, 3, 4);
            dashUpdtPhoneNumber.Name = "dashUpdtPhoneNumber";
            dashUpdtPhoneNumber.Size = new Size(216, 20);
            dashUpdtPhoneNumber.TabIndex = 7;
            dashUpdtPhoneNumber.TextChanged += dashUpdtPhoneNumber_TextChanged;
            // 
            // lbl6
            // 
            lbl6.AutoSize = true;
            lbl6.FlatStyle = FlatStyle.Flat;
            lbl6.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbl6.ForeColor = Color.DarkSlateGray;
            lbl6.Location = new Point(447, 171);
            lbl6.Name = "lbl6";
            lbl6.RightToLeft = RightToLeft.No;
            lbl6.Size = new Size(85, 17);
            lbl6.TabIndex = 6;
            lbl6.Text = "Nationality :";
            lbl6.TextAlign = ContentAlignment.MiddleRight;
            // 
            // dashUpdtNationality
            // 
            dashUpdtNationality.BackColor = Color.FromArgb(230, 231, 233);
            dashUpdtNationality.BorderStyle = BorderStyle.None;
            dashUpdtNationality.Location = new Point(535, 169);
            dashUpdtNationality.Margin = new Padding(3, 4, 3, 4);
            dashUpdtNationality.Name = "dashUpdtNationality";
            dashUpdtNationality.Size = new Size(216, 20);
            dashUpdtNationality.TabIndex = 7;
            dashUpdtNationality.TextChanged += dashUpdtNationality_TextChanged;
            // 
            // lbl7
            // 
            lbl7.AutoSize = true;
            lbl7.FlatStyle = FlatStyle.Flat;
            lbl7.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbl7.ForeColor = Color.DarkSlateGray;
            lbl7.Location = new Point(427, 380);
            lbl7.Name = "lbl7";
            lbl7.RightToLeft = RightToLeft.No;
            lbl7.Size = new Size(102, 17);
            lbl7.TabIndex = 6;
            lbl7.Text = "Marital Status :";
            lbl7.TextAlign = ContentAlignment.MiddleRight;
            // 
            // dashUpdtMaritalStatus
            // 
            dashUpdtMaritalStatus.BackColor = Color.FromArgb(230, 231, 233);
            dashUpdtMaritalStatus.BorderStyle = BorderStyle.None;
            dashUpdtMaritalStatus.Location = new Point(535, 379);
            dashUpdtMaritalStatus.Margin = new Padding(3, 4, 3, 4);
            dashUpdtMaritalStatus.Name = "dashUpdtMaritalStatus";
            dashUpdtMaritalStatus.Size = new Size(216, 20);
            dashUpdtMaritalStatus.TabIndex = 7;
            dashUpdtMaritalStatus.TextChanged += dashUpdtMaritalStatus_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.FlatStyle = FlatStyle.Flat;
            label3.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.DarkSlateGray;
            label3.Location = new Point(75, 325);
            label3.Name = "label3";
            label3.Size = new Size(81, 17);
            label3.TabIndex = 6;
            label3.Text = "Last Name :";
            label3.TextAlign = ContentAlignment.MiddleRight;
            // 
            // dashUpdtLastName
            // 
            dashUpdtLastName.BackColor = Color.FromArgb(230, 231, 233);
            dashUpdtLastName.BorderStyle = BorderStyle.None;
            dashUpdtLastName.Location = new Point(158, 324);
            dashUpdtLastName.Margin = new Padding(3, 4, 3, 4);
            dashUpdtLastName.Name = "dashUpdtLastName";
            dashUpdtLastName.Size = new Size(216, 20);
            dashUpdtLastName.TabIndex = 7;
            dashUpdtLastName.TextChanged += dashUpdtLastName_TextChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.FlatStyle = FlatStyle.Flat;
            label4.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.DarkSlateGray;
            label4.Location = new Point(466, 325);
            label4.Name = "label4";
            label4.RightToLeft = RightToLeft.No;
            label4.Size = new Size(67, 17);
            label4.TabIndex = 6;
            label4.Text = "Religion :";
            label4.TextAlign = ContentAlignment.MiddleRight;
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.FlatStyle = FlatStyle.Flat;
            label5.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.DarkSlateGray;
            label5.Location = new Point(455, 269);
            label5.Name = "label5";
            label5.RightToLeft = RightToLeft.No;
            label5.Size = new Size(78, 17);
            label5.TabIndex = 6;
            label5.Text = "University :";
            label5.TextAlign = ContentAlignment.MiddleRight;
            // 
            // dashUpdtUniversity
            // 
            dashUpdtUniversity.BackColor = Color.FromArgb(230, 231, 233);
            dashUpdtUniversity.BorderStyle = BorderStyle.None;
            dashUpdtUniversity.Location = new Point(535, 269);
            dashUpdtUniversity.Margin = new Padding(3, 4, 3, 4);
            dashUpdtUniversity.Name = "dashUpdtUniversity";
            dashUpdtUniversity.Size = new Size(216, 20);
            dashUpdtUniversity.TabIndex = 7;
            dashUpdtUniversity.TextChanged += dashUpdtUniversity_TextChanged;
            // 
            // dashUpdtEmail
            // 
            dashUpdtEmail.BackColor = Color.FromArgb(230, 231, 233);
            dashUpdtEmail.BorderStyle = BorderStyle.None;
            dashUpdtEmail.Location = new Point(535, 219);
            dashUpdtEmail.Margin = new Padding(3, 4, 3, 4);
            dashUpdtEmail.Name = "dashUpdtEmail";
            dashUpdtEmail.Size = new Size(216, 20);
            dashUpdtEmail.TabIndex = 9;
            dashUpdtEmail.TextChanged += dashUpdtEmail_TextChanged;
            // 
            // lbl3
            // 
            lbl3.AutoSize = true;
            lbl3.FlatStyle = FlatStyle.Flat;
            lbl3.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbl3.ForeColor = Color.DarkSlateGray;
            lbl3.Location = new Point(483, 220);
            lbl3.Name = "lbl3";
            lbl3.RightToLeft = RightToLeft.No;
            lbl3.Size = new Size(50, 17);
            lbl3.TabIndex = 8;
            lbl3.Text = "Email :";
            lbl3.TextAlign = ContentAlignment.MiddleRight;
            // 
            // dashUpdtSubmit
            // 
            dashUpdtSubmit.BackColor = Color.DarkSlateGray;
            dashUpdtSubmit.BackgroundImageLayout = ImageLayout.None;
            dashUpdtSubmit.Cursor = Cursors.Hand;
            dashUpdtSubmit.FlatStyle = FlatStyle.Popup;
            dashUpdtSubmit.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            dashUpdtSubmit.ForeColor = Color.White;
            dashUpdtSubmit.Location = new Point(353, 460);
            dashUpdtSubmit.Name = "dashUpdtSubmit";
            dashUpdtSubmit.Size = new Size(107, 43);
            dashUpdtSubmit.TabIndex = 10;
            dashUpdtSubmit.Text = "Submit";
            dashUpdtSubmit.UseVisualStyleBackColor = false;
            dashUpdtSubmit.Click += dashUpdtSubmit_Click_1;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Perpetua Titling MT", 14.25F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point);
            label7.ForeColor = Color.DarkSlateGray;
            label7.Location = new Point(279, 48);
            label7.Name = "label7";
            label7.Size = new Size(266, 23);
            label7.TabIndex = 11;
            label7.Text = "       Update Profile       ";
            // 
            // dashUpdtReligion
            // 
            dashUpdtReligion.BackColor = Color.FromArgb(230, 231, 233);
            dashUpdtReligion.BorderStyle = BorderStyle.None;
            dashUpdtReligion.Location = new Point(535, 324);
            dashUpdtReligion.Margin = new Padding(3, 4, 3, 4);
            dashUpdtReligion.Name = "dashUpdtReligion";
            dashUpdtReligion.Size = new Size(216, 20);
            dashUpdtReligion.TabIndex = 7;
            dashUpdtReligion.TextChanged += dashUpdtReligion_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.FlatStyle = FlatStyle.Flat;
            label6.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.DarkSlateGray;
            label6.Location = new Point(80, 171);
            label6.Name = "label6";
            label6.RightToLeft = RightToLeft.No;
            label6.Size = new Size(77, 17);
            label6.TabIndex = 6;
            label6.Text = "Username :";
            label6.TextAlign = ContentAlignment.MiddleRight;
            label6.Click += label6_Click;
            // 
            // targetUser
            // 
            targetUser.BackColor = Color.FromArgb(230, 231, 233);
            targetUser.BorderStyle = BorderStyle.None;
            targetUser.Font = new Font("Nirmala UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            targetUser.Location = new Point(158, 171);
            targetUser.Name = "targetUser";
            targetUser.Size = new Size(216, 20);
            targetUser.TabIndex = 13;
            targetUser.TextChanged += targetUser_TextChanged;
            // 
            // exitbtn
            // 
            exitbtn.Cursor = Cursors.Hand;
            exitbtn.Image = (Image)resources.GetObject("exitbtn.Image");
            exitbtn.Location = new Point(795, 3);
            exitbtn.Name = "exitbtn";
            exitbtn.Size = new Size(25, 24);
            exitbtn.SizeMode = PictureBoxSizeMode.Zoom;
            exitbtn.TabIndex = 39;
            exitbtn.TabStop = false;
            exitbtn.Click += exitbtn_Click;
            // 
            // uc_updateProfile
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(exitbtn);
            Controls.Add(targetUser);
            Controls.Add(label7);
            Controls.Add(dashUpdtSubmit);
            Controls.Add(dashUpdtEmail);
            Controls.Add(lbl3);
            Controls.Add(dashUpdtMaritalStatus);
            Controls.Add(lbl7);
            Controls.Add(dashUpdtNationality);
            Controls.Add(lbl6);
            Controls.Add(dashUpdtReligion);
            Controls.Add(dashUpdtPhoneNumber);
            Controls.Add(lbl4);
            Controls.Add(dashUpdtUniversity);
            Controls.Add(label5);
            Controls.Add(dashUpdtUsername);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(dashUpdtLastName);
            Controls.Add(label3);
            Controls.Add(dashUpdtFirstName);
            Controls.Add(label1);
            Font = new Font("Nirmala UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            Margin = new Padding(3, 4, 3, 4);
            Name = "uc_updateProfile";
            Size = new Size(823, 580);
            Load += uc_updateProfile_Load;
            ((System.ComponentModel.ISupportInitialize)exitbtn).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private TextBox dashUpdtFirstName;
        private Label label2;
        private TextBox dashUpdtUsername;
        private Label lbl4;
        private TextBox dashUpdtPhoneNumber;
        private Label lbl6;
        private TextBox dashUpdtNationality;
        private Label lbl7;
        private TextBox dashUpdtMaritalStatus;
        private Label label3;
        private TextBox dashUpdtLastName;
        private Label label4;
        private Label label5;
        private TextBox dashUpdtUniversity;
        private TextBox dashUpdtEmail;
        private Label lbl3;
        private Button dashUpdtSubmit;
        private Label label7;
        private TextBox dashUpdtReligion;
        private Label label6;
        private TextBox targetUser;
        private PictureBox exitbtn;
    }
}

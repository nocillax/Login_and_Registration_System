﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_System
{
    public partial class uc_createUser : UserControl
    {
        public uc_createUser()
        {
            InitializeComponent();
        }

        private void crtUser_TextChanged(object sender, EventArgs e)
        {

        }

        private void dashcrtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void dashcrtFirstName_TextChanged(object sender, EventArgs e)
        {

        }

        private void dashcrtNationality_TextChanged(object sender, EventArgs e)
        {

        }

        private void dashcrtPhoneNumber_TextChanged(object sender, EventArgs e)
        {
        }

        private void dashcrtMaritalStatus_TextChanged(object sender, EventArgs e)
        {
        }

        private void dashcrtReligion_TextChanged(object sender, EventArgs e)
        {
        }

        private void dashcrtUniversity_TextChanged(object sender, EventArgs e)
        {
        }

        private void dashcrtEmail_TextChanged(object sender, EventArgs e)
        {
        }

        private void dashcrtLastName_TextChanged(object sender, EventArgs e)
        {
        }

        private bool IsUsernameAvailable(string username)
        {
            try
            {
                string connectionString = @"Data Source=DESKTOP-H9MPPVO\SQLEXPRESS;Initial Catalog=UserRegistrationDB;Integrated Security=True;Encrypt=False;"; // Replace with your actual connection string

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Check if the username is already in use
                    string checkUsernameQuery = @"SELECT COUNT(*)
                                                  FROM Users
                                                  WHERE Username = @Username";

                    using (SqlCommand checkUsernameCommand = new SqlCommand(checkUsernameQuery, connection))
                    {
                        checkUsernameCommand.Parameters.AddWithValue("@Username", username);

                        int existingUserCount = (int)checkUsernameCommand.ExecuteScalar();

                        // If the count is greater than 0, the username is already in use
                        return existingUserCount == 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while checking the username: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false; // Return false in case of an error
            }
        }

        private void CreateUser(string username, string password, string firstName, string lastName, string phoneNumber, string religion, string nationality, string maritalStatus, string university, string email, string userRole)
        {
            try
            {
                string connectionString = @"Data Source=DESKTOP-H9MPPVO\SQLEXPRESS;Initial Catalog=UserRegistrationDB;Integrated Security=True;Encrypt=False;";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string insertQuery = @"INSERT INTO Users (Username, Password, FirstName, LastName, PhoneNumber, Religion, Nationality, MaritalStatus, University, Email, UserRole)
                                  VALUES (@Username, @Password, @FirstName, @LastName, @PhoneNumber, @Religion, @Nationality, @MaritalStatus, @University, @Email, @UserRole)";

                    using (SqlCommand insertCommand = new SqlCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@Username", username);
                        insertCommand.Parameters.AddWithValue("@Password", password);
                        insertCommand.Parameters.AddWithValue("@FirstName", firstName);
                        insertCommand.Parameters.AddWithValue("@LastName", lastName);
                        insertCommand.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                        insertCommand.Parameters.AddWithValue("@Religion", religion);
                        insertCommand.Parameters.AddWithValue("@Nationality", nationality);
                        insertCommand.Parameters.AddWithValue("@MaritalStatus", maritalStatus);
                        insertCommand.Parameters.AddWithValue("@University", university);
                        insertCommand.Parameters.AddWithValue("@Email", email);
                        insertCommand.Parameters.AddWithValue("@UserRole", userRole);

                        int rowsAffected = insertCommand.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            // User created successfully
                        }
                        else
                        {
                            MessageBox.Show("Failed to create user. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void dashcrtCreate_Click(object sender, EventArgs e)
        {
            // Get the user's data from the form
            string newUsername = crtUser.Text;
            string newPassword = dashcrtPassword.Text;
            string firstName = dashcrtFirstName.Text;
            string lastName = dashcrtLastName.Text;
            string phoneNumber = dashcrtPhoneNumber.Text;
            string religion = dashcrtReligion.Text;
            string nationality = dashcrtNationality.Text;
            string maritalStatus = dashcrtMaritalStatus.Text;
            string university = dashcrtUniversity.Text;
            string email = dashcrtEmail.Text;

            // Check if username or password is empty
            if (string.IsNullOrEmpty(newUsername) || string.IsNullOrEmpty(newPassword))
            {
                MessageBox.Show("Please enter both username and password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Check if the provided username is already in use
            if (!IsUsernameAvailable(newUsername))
            {
                MessageBox.Show("The provided username is already in use. Please choose a different username.",
                                "Username In Use", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check if a UserRole is selected
            if (userRoleBox.SelectedItem == null)
            {
                MessageBox.Show("Please select a user role.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Get the selected UserRole from the ComboBox
            string userRole = userRoleBox.SelectedItem.ToString();

            // Check if a user role is selected
            if (string.IsNullOrEmpty(userRole))
            {
                MessageBox.Show("Please select a user role.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Create the new user in the database
            CreateUser(newUsername, newPassword, firstName, lastName, phoneNumber, religion, nationality, maritalStatus, university, email, userRole);

            MessageBox.Show("User created successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Clear the textboxes after user creation
            crtUser.Text = "";
            dashcrtPassword.Text = "";
            dashcrtFirstName.Text = "";
            dashcrtLastName.Text = "";
            dashcrtPhoneNumber.Text = "";
            dashcrtReligion.Text = "";
            dashcrtNationality.Text = "";
            dashcrtMaritalStatus.Text = "";
            dashcrtUniversity.Text = "";
            dashcrtEmail.Text = "";
            userRoleBox.SelectedIndex = -1; // Clear the selected user role
        }

        private void userRoleBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void uc_createUser_Load(object sender, EventArgs e)
        {

        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

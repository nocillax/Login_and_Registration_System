﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_System
{
    public partial class usrDashboard : Form
    {
        public usrDashboard()
        {
            InitializeComponent();
        }

        private void UpdateLabel_Click(object sender, EventArgs e)
        {
            // Create an instance of uc_updateProfile
            uc_updateProfile ucUpdateProfile = new uc_updateProfile();

            // Clear the existing controls in the panel
            uc_usrdashboardPanel.Controls.Clear();

            // Add the uc_updateProfile user control to the panel
            uc_usrdashboardPanel.Controls.Add(ucUpdateProfile);

            // Set the Dock property to fill the panel
            ucUpdateProfile.Dock = DockStyle.Fill;
        }

        private void uc_usrdashboardPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void UpdtLabel_Click(object sender, EventArgs e)
        {
            UpdateLabel_Click(sender, e);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            new frmLogin().Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            pictureBox1_Click(sender, e);
        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

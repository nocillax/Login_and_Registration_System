﻿namespace Login_System
{
    partial class frmRegister
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRegister));
            label1 = new Label();
            label2 = new Label();
            txtUsername = new TextBox();
            label3 = new Label();
            txtPassword = new TextBox();
            checkbxShowPas = new CheckBox();
            Register = new Button();
            alreadyhaveacc = new Label();
            loginbtn = new Label();
            label5 = new Label();
            txtFirstName = new TextBox();
            label6 = new Label();
            txtLastName = new TextBox();
            label7 = new Label();
            txtEmail = new TextBox();
            label8 = new Label();
            txtComPassword = new TextBox();
            exitbtn = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)exitbtn).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Perpetua Titling MT", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.DarkSlateGray;
            label1.Location = new Point(157, 42);
            label1.Name = "label1";
            label1.Size = new Size(212, 32);
            label1.TabIndex = 0;
            label1.Text = "Get Started";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(38, 188);
            label2.Name = "label2";
            label2.Size = new Size(69, 17);
            label2.TabIndex = 1;
            label2.Text = "Username";
            // 
            // txtUsername
            // 
            txtUsername.BackColor = Color.FromArgb(230, 231, 233);
            txtUsername.BorderStyle = BorderStyle.None;
            txtUsername.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtUsername.Location = new Point(35, 208);
            txtUsername.Multiline = true;
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(216, 25);
            txtUsername.TabIndex = 2;
            txtUsername.TextChanged += txtUsername_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(38, 256);
            label3.Name = "label3";
            label3.Size = new Size(66, 17);
            label3.TabIndex = 1;
            label3.Text = "Password";
            // 
            // txtPassword
            // 
            txtPassword.BackColor = Color.FromArgb(230, 231, 233);
            txtPassword.BorderStyle = BorderStyle.None;
            txtPassword.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtPassword.Location = new Point(35, 276);
            txtPassword.Multiline = true;
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '•';
            txtPassword.Size = new Size(216, 25);
            txtPassword.TabIndex = 2;
            // 
            // checkbxShowPas
            // 
            checkbxShowPas.AutoSize = true;
            checkbxShowPas.Cursor = Cursors.Hand;
            checkbxShowPas.FlatStyle = FlatStyle.Flat;
            checkbxShowPas.Location = new Point(35, 316);
            checkbxShowPas.Name = "checkbxShowPas";
            checkbxShowPas.Size = new Size(119, 21);
            checkbxShowPas.TabIndex = 3;
            checkbxShowPas.Text = "Show Password";
            checkbxShowPas.UseVisualStyleBackColor = true;
            checkbxShowPas.CheckedChanged += checkbxShowPas_CheckedChanged;
            // 
            // Register
            // 
            Register.BackColor = Color.DarkSlateGray;
            Register.Cursor = Cursors.Hand;
            Register.FlatAppearance.BorderSize = 0;
            Register.FlatStyle = FlatStyle.Flat;
            Register.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Register.ForeColor = Color.White;
            Register.Location = new Point(157, 382);
            Register.Name = "Register";
            Register.Size = new Size(216, 35);
            Register.TabIndex = 4;
            Register.Text = "REGISTER";
            Register.UseVisualStyleBackColor = false;
            Register.Click += Register_Click;
            // 
            // alreadyhaveacc
            // 
            alreadyhaveacc.AutoSize = true;
            alreadyhaveacc.Location = new Point(186, 438);
            alreadyhaveacc.Name = "alreadyhaveacc";
            alreadyhaveacc.Size = new Size(165, 17);
            alreadyhaveacc.TabIndex = 5;
            alreadyhaveacc.Text = "Already have an account?";
            alreadyhaveacc.Click += label5_Click;
            // 
            // loginbtn
            // 
            loginbtn.AutoSize = true;
            loginbtn.Cursor = Cursors.Hand;
            loginbtn.ForeColor = Color.DarkSlateGray;
            loginbtn.Location = new Point(240, 468);
            loginbtn.Name = "loginbtn";
            loginbtn.Size = new Size(48, 17);
            loginbtn.TabIndex = 6;
            loginbtn.Text = "LOGIN";
            loginbtn.Click += label5_Click_1;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(38, 115);
            label5.Name = "label5";
            label5.Size = new Size(75, 17);
            label5.TabIndex = 1;
            label5.Text = "First Name";
            label5.Click += label5_Click_2;
            // 
            // txtFirstName
            // 
            txtFirstName.BackColor = Color.FromArgb(230, 231, 233);
            txtFirstName.BorderStyle = BorderStyle.None;
            txtFirstName.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtFirstName.Location = new Point(35, 135);
            txtFirstName.Multiline = true;
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(216, 25);
            txtFirstName.TabIndex = 2;
            txtFirstName.TextChanged += textBox1_TextChanged_1;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(284, 115);
            label6.Name = "label6";
            label6.Size = new Size(73, 17);
            label6.TabIndex = 1;
            label6.Text = "Last Name";
            label6.Click += label5_Click_2;
            // 
            // txtLastName
            // 
            txtLastName.BackColor = Color.FromArgb(230, 231, 233);
            txtLastName.BorderStyle = BorderStyle.None;
            txtLastName.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtLastName.Location = new Point(281, 135);
            txtLastName.Multiline = true;
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(216, 25);
            txtLastName.TabIndex = 2;
            txtLastName.TextChanged += textBox1_TextChanged_1;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(284, 188);
            label7.Name = "label7";
            label7.Size = new Size(42, 17);
            label7.TabIndex = 1;
            label7.Text = "Email";
            // 
            // txtEmail
            // 
            txtEmail.BackColor = Color.FromArgb(230, 231, 233);
            txtEmail.BorderStyle = BorderStyle.None;
            txtEmail.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtEmail.Location = new Point(281, 208);
            txtEmail.Multiline = true;
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(216, 25);
            txtEmail.TabIndex = 2;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(284, 256);
            label8.Name = "label8";
            label8.Size = new Size(120, 17);
            label8.TabIndex = 1;
            label8.Text = "Confirm Password";
            label8.Click += label4_Click;
            // 
            // txtComPassword
            // 
            txtComPassword.BackColor = Color.FromArgb(230, 231, 233);
            txtComPassword.BorderStyle = BorderStyle.None;
            txtComPassword.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtComPassword.Location = new Point(281, 276);
            txtComPassword.Multiline = true;
            txtComPassword.Name = "txtComPassword";
            txtComPassword.PasswordChar = '•';
            txtComPassword.Size = new Size(216, 25);
            txtComPassword.TabIndex = 2;
            txtComPassword.TextChanged += textBox1_TextChanged;
            // 
            // exitbtn
            // 
            exitbtn.Cursor = Cursors.Hand;
            exitbtn.Image = (Image)resources.GetObject("exitbtn.Image");
            exitbtn.Location = new Point(507, 2);
            exitbtn.Name = "exitbtn";
            exitbtn.Size = new Size(25, 24);
            exitbtn.SizeMode = PictureBoxSizeMode.Zoom;
            exitbtn.TabIndex = 7;
            exitbtn.TabStop = false;
            exitbtn.Click += exitbtn_Click;
            // 
            // frmRegister
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(534, 530);
            Controls.Add(exitbtn);
            Controls.Add(loginbtn);
            Controls.Add(alreadyhaveacc);
            Controls.Add(Register);
            Controls.Add(checkbxShowPas);
            Controls.Add(txtComPassword);
            Controls.Add(label8);
            Controls.Add(txtPassword);
            Controls.Add(label3);
            Controls.Add(txtLastName);
            Controls.Add(label6);
            Controls.Add(txtFirstName);
            Controls.Add(label5);
            Controls.Add(txtEmail);
            Controls.Add(label7);
            Controls.Add(txtUsername);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            ForeColor = Color.FromArgb(164, 165, 169);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmRegister";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += frmRegister_Load;
            ((System.ComponentModel.ISupportInitialize)exitbtn).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtUsername;
        private Label label3;
        private TextBox txtPassword;
        private CheckBox checkbxShowPas;
        private Button Register;
        private Label alreadyhaveacc;
        private Label loginbtn;
        private Label label5;
        private TextBox txtFirstName;
        private Label label6;
        private TextBox txtLastName;
        private Label label7;
        private TextBox txtEmail;
        private Label label8;
        private TextBox txtComPassword;
        private PictureBox exitbtn;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_System
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_2(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void dashUpdateProfile_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void uc_dashboardPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void sideBar_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            // Create an instance of uc_updateProfile
            uc_updateProfile ucUpdateProfile = new uc_updateProfile();

            // Clear the existing controls in the panel
            uc_dashboardPanel.Controls.Clear();

            // Add the uc_updateProfile user control to the panel
            uc_dashboardPanel.Controls.Add(ucUpdateProfile);

            // Set the Dock property to fill the panel
            ucUpdateProfile.Dock = DockStyle.Fill;
        }

        private void CreatePic_Click(object sender, EventArgs e)
        {
            // Create an instance of uc_createUser
            uc_createUser uccreateUser = new uc_createUser();

            // Clear the existing controls in the panel
            uc_dashboardPanel.Controls.Clear();

            // Add the uc_createUser user control to the panel
            uc_dashboardPanel.Controls.Add(uccreateUser);

            // Set the Dock property to fill the panel
            uccreateUser.Dock = DockStyle.Fill;
        }

        private void ReadPic_Click(object sender, EventArgs e)
        {
            // Create an instance of uc_createUser
            uc_ReadUsers ucReadUsers = new uc_ReadUsers();

            // Clear the existing controls in the panel
            uc_dashboardPanel.Controls.Clear();

            // Add the uc_createUser user control to the panel
            uc_dashboardPanel.Controls.Add(ucReadUsers);

            // Set the Dock property to fill the panel
            ucReadUsers.Dock = DockStyle.Fill;
        }

        private void LogOutpic_Click(object sender, EventArgs e)
        {
            new frmLogin().Show();
            this.Hide();
        }

        private void CreateLbl_Click(object sender, EventArgs e)
        {
            CreatePic_Click(sender, e);
        }

        private void ReadLabel_Click(object sender, EventArgs e)
        {
            ReadPic_Click(sender, e);
        }

        private void UpdtLabel_Click(object sender, EventArgs e)
        {
            pictureBox2_Click_1(sender, e);
        }

        private void LogOutLbl_Click(object sender, EventArgs e)
        {
            LogOutpic_Click(sender, e);
        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

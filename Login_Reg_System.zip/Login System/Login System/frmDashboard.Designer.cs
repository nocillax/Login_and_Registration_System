﻿namespace Login_System
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            UpdateLabel = new PictureBox();
            UpdtLabel = new Label();
            ReadLabel = new Label();
            CreateLbl = new Label();
            sideBar = new PictureBox();
            CreatePic = new PictureBox();
            ReadPic = new PictureBox();
            uc_dashboardPanel = new Panel();
            exitbtn = new PictureBox();
            LogOutLbl = new Label();
            LogOutpic = new PictureBox();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)UpdateLabel).BeginInit();
            ((System.ComponentModel.ISupportInitialize)sideBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)CreatePic).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ReadPic).BeginInit();
            uc_dashboardPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)exitbtn).BeginInit();
            ((System.ComponentModel.ISupportInitialize)LogOutpic).BeginInit();
            SuspendLayout();
            // 
            // UpdateLabel
            // 
            UpdateLabel.BackColor = Color.LightSteelBlue;
            UpdateLabel.Cursor = Cursors.Hand;
            UpdateLabel.Image = (Image)resources.GetObject("UpdateLabel.Image");
            UpdateLabel.Location = new Point(24, 323);
            UpdateLabel.Margin = new Padding(3, 4, 3, 4);
            UpdateLabel.Name = "UpdateLabel";
            UpdateLabel.Size = new Size(30, 30);
            UpdateLabel.SizeMode = PictureBoxSizeMode.Zoom;
            UpdateLabel.TabIndex = 7;
            UpdateLabel.TabStop = false;
            UpdateLabel.Click += pictureBox2_Click_1;
            // 
            // UpdtLabel
            // 
            UpdtLabel.AutoSize = true;
            UpdtLabel.BackColor = Color.LightSteelBlue;
            UpdtLabel.Cursor = Cursors.Hand;
            UpdtLabel.FlatStyle = FlatStyle.Flat;
            UpdtLabel.Font = new Font("Perpetua Titling MT", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            UpdtLabel.ForeColor = Color.Black;
            UpdtLabel.Location = new Point(8, 361);
            UpdtLabel.Name = "UpdtLabel";
            UpdtLabel.Size = new Size(64, 16);
            UpdtLabel.TabIndex = 9;
            UpdtLabel.Text = "Update";
            UpdtLabel.Click += UpdtLabel_Click;
            // 
            // ReadLabel
            // 
            ReadLabel.AutoSize = true;
            ReadLabel.BackColor = Color.LightSteelBlue;
            ReadLabel.Cursor = Cursors.Hand;
            ReadLabel.FlatStyle = FlatStyle.Flat;
            ReadLabel.Font = new Font("Perpetua Titling MT", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            ReadLabel.ForeColor = Color.Black;
            ReadLabel.Location = new Point(17, 234);
            ReadLabel.Name = "ReadLabel";
            ReadLabel.Size = new Size(46, 16);
            ReadLabel.TabIndex = 9;
            ReadLabel.Text = "Read";
            ReadLabel.Click += ReadLabel_Click;
            // 
            // CreateLbl
            // 
            CreateLbl.AutoSize = true;
            CreateLbl.BackColor = Color.LightSteelBlue;
            CreateLbl.Cursor = Cursors.Hand;
            CreateLbl.FlatStyle = FlatStyle.Flat;
            CreateLbl.Font = new Font("Perpetua Titling MT", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            CreateLbl.ForeColor = Color.Black;
            CreateLbl.Location = new Point(9, 112);
            CreateLbl.Name = "CreateLbl";
            CreateLbl.Size = new Size(61, 16);
            CreateLbl.TabIndex = 9;
            CreateLbl.Text = "Create";
            CreateLbl.Click += CreateLbl_Click;
            // 
            // sideBar
            // 
            sideBar.BackColor = Color.LightSteelBlue;
            sideBar.Location = new Point(0, 0);
            sideBar.Margin = new Padding(3, 4, 3, 4);
            sideBar.Name = "sideBar";
            sideBar.Size = new Size(79, 580);
            sideBar.TabIndex = 6;
            sideBar.TabStop = false;
            sideBar.Click += sideBar_Click;
            // 
            // CreatePic
            // 
            CreatePic.BackColor = Color.LightSteelBlue;
            CreatePic.Cursor = Cursors.Hand;
            CreatePic.Image = (Image)resources.GetObject("CreatePic.Image");
            CreatePic.Location = new Point(25, 75);
            CreatePic.Name = "CreatePic";
            CreatePic.Size = new Size(30, 30);
            CreatePic.SizeMode = PictureBoxSizeMode.Zoom;
            CreatePic.TabIndex = 10;
            CreatePic.TabStop = false;
            CreatePic.Click += CreatePic_Click;
            // 
            // ReadPic
            // 
            ReadPic.BackColor = Color.LightSteelBlue;
            ReadPic.Cursor = Cursors.Hand;
            ReadPic.Image = (Image)resources.GetObject("ReadPic.Image");
            ReadPic.Location = new Point(25, 197);
            ReadPic.Name = "ReadPic";
            ReadPic.Size = new Size(30, 30);
            ReadPic.SizeMode = PictureBoxSizeMode.Zoom;
            ReadPic.TabIndex = 0;
            ReadPic.TabStop = false;
            ReadPic.Click += ReadPic_Click;
            // 
            // uc_dashboardPanel
            // 
            uc_dashboardPanel.Controls.Add(label2);
            uc_dashboardPanel.Controls.Add(exitbtn);
            uc_dashboardPanel.Location = new Point(79, 0);
            uc_dashboardPanel.Name = "uc_dashboardPanel";
            uc_dashboardPanel.Size = new Size(821, 580);
            uc_dashboardPanel.TabIndex = 8;
            uc_dashboardPanel.Paint += uc_dashboardPanel_Paint;
            // 
            // exitbtn
            // 
            exitbtn.Cursor = Cursors.Hand;
            exitbtn.Image = (Image)resources.GetObject("exitbtn.Image");
            exitbtn.Location = new Point(793, 3);
            exitbtn.Name = "exitbtn";
            exitbtn.Size = new Size(25, 24);
            exitbtn.SizeMode = PictureBoxSizeMode.Zoom;
            exitbtn.TabIndex = 20;
            exitbtn.TabStop = false;
            exitbtn.Click += exitbtn_Click;
            // 
            // LogOutLbl
            // 
            LogOutLbl.AutoSize = true;
            LogOutLbl.BackColor = Color.LightSteelBlue;
            LogOutLbl.Cursor = Cursors.Hand;
            LogOutLbl.FlatStyle = FlatStyle.Flat;
            LogOutLbl.Font = new Font("Perpetua Titling MT", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            LogOutLbl.ForeColor = Color.Black;
            LogOutLbl.Location = new Point(5, 486);
            LogOutLbl.Name = "LogOutLbl";
            LogOutLbl.Size = new Size(71, 16);
            LogOutLbl.TabIndex = 12;
            LogOutLbl.Text = "Log Out";
            LogOutLbl.Click += LogOutLbl_Click;
            // 
            // LogOutpic
            // 
            LogOutpic.BackColor = Color.LightSteelBlue;
            LogOutpic.Cursor = Cursors.Hand;
            LogOutpic.Image = (Image)resources.GetObject("LogOutpic.Image");
            LogOutpic.Location = new Point(25, 448);
            LogOutpic.Margin = new Padding(3, 4, 3, 4);
            LogOutpic.Name = "LogOutpic";
            LogOutpic.Size = new Size(30, 30);
            LogOutpic.SizeMode = PictureBoxSizeMode.Zoom;
            LogOutpic.TabIndex = 11;
            LogOutpic.TabStop = false;
            LogOutpic.Click += LogOutpic_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Perpetua Titling MT", 36F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point);
            label2.ForeColor = Color.DarkSlateGray;
            label2.Location = new Point(128, 249);
            label2.Name = "label2";
            label2.Size = new Size(564, 58);
            label2.TabIndex = 22;
            label2.Text = "ADMIN DASHBOARD";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(900, 580);
            Controls.Add(uc_dashboardPanel);
            Controls.Add(LogOutLbl);
            Controls.Add(LogOutpic);
            Controls.Add(ReadPic);
            Controls.Add(CreatePic);
            Controls.Add(CreateLbl);
            Controls.Add(ReadLabel);
            Controls.Add(UpdtLabel);
            Controls.Add(UpdateLabel);
            Controls.Add(sideBar);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)UpdateLabel).EndInit();
            ((System.ComponentModel.ISupportInitialize)sideBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)CreatePic).EndInit();
            ((System.ComponentModel.ISupportInitialize)ReadPic).EndInit();
            uc_dashboardPanel.ResumeLayout(false);
            uc_dashboardPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)exitbtn).EndInit();
            ((System.ComponentModel.ISupportInitialize)LogOutpic).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox UpdateLabel;
        private Label UpdtLabel;
        private Label ReadLabel;
        private Label CreateLbl;
        private PictureBox sideBar;
        private PictureBox CreatePic;
        private PictureBox ReadPic;
        private Panel uc_dashboardPanel;
        private Label LogOutLbl;
        private PictureBox LogOutpic;
        private PictureBox exitbtn;
        private Label label2;
    }
}
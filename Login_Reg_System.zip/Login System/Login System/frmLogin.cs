﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;




namespace Login_System
{
    public partial class frmLogin : Form
    {

        string connectionString = @"Data Source=DESKTOP-H9MPPVO\SQLEXPRESS;Initial Catalog=UserRegistrationDB;Integrated Security=True;Encrypt=False;";
        public frmLogin()
        {
            InitializeComponent();
        }


        private void Login_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Username and password are required.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Check if the username and password match (case-sensitive)
                string query = "SELECT COUNT(*) FROM Users WHERE Username = @Username COLLATE Latin1_General_CS_AS AND Password = @Password COLLATE Latin1_General_CS_AS";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    int userCount = (int)command.ExecuteScalar();

                    if (userCount > 0)
                    {
                        // Check the UserRole of the user
                        string userRoleQuery = "SELECT UserRole FROM Users WHERE Username = @Username";
                        using (SqlCommand userRoleCommand = new SqlCommand(userRoleQuery, connection))
                        {
                            userRoleCommand.Parameters.AddWithValue("@Username", username);
                            string userRole = userRoleCommand.ExecuteScalar()?.ToString();

                            // Navigate to the appropriate form based on UserRole
                            if (userRole == "Admin")
                            {
                                // Show the Admin Dashboard form (frmDashboard)
                                Form1 adminDashboard = new Form1();
                                adminDashboard.Show();
                            }
                            else if (userRole == "User")
                            {
                                // Show the User Dashboard form (usrDashboard)
                                usrDashboard userDashboard = new usrDashboard();
                                userDashboard.Show();
                            }
                            else
                            {
                                MessageBox.Show("Invalid user role.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }


        private void label6_Click(object sender, EventArgs e)
        {
            frmRegister registerForm = new frmRegister();
            registerForm.Show();  // Use Show() instead of Show
            this.Hide();  // Optional: hide the login form if needed
        }


        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void frmLogin_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_2(object sender, EventArgs e)
        {

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void checkbxShowPas_CheckedChanged(object sender, EventArgs e)
        {
            if (checkbxShowPas.Checked)
            {
                txtPassword.PasswordChar = '\0';
                
            }
            else
            {
                txtPassword.PasswordChar = '•';
                
            }
        }
    }
}

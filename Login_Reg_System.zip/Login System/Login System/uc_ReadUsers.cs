﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_System
{
    public partial class uc_ReadUsers : UserControl
    {

        private SqlDataAdapter dataAdapter;
        private DataSet dataSet;
        string selectedUsername;
        public uc_ReadUsers()
        {
            InitializeComponent();
            InitializeDataGridView("");
            readUserDataDGV.CellClick += readUserDataDGV_CellClick;
            //     deleteButton.Click += deleteButton_Click;
        }

        private void InitializeDataGridView(string username)
        {
            try
            {
                string connectionString = @"Data Source=DESKTOP-H9MPPVO\SQLEXPRESS;Initial Catalog=UserRegistrationDB;Integrated Security=True;Encrypt=False;";


                if (string.IsNullOrEmpty(username))
                {
                    // If username is null or empty, set DataSource to null
                    readUserDataDGV.DataSource = null;
                }
                else
                {
                    string query = $"SELECT Username, UserRole, Email, FirstName, LastName, PhoneNumber, Religion, Nationality, MaritalStatus, University FROM Users WHERE Username = '{username}'";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        dataAdapter = new SqlDataAdapter(query, connection);
                        dataSet = new DataSet();

                        // Fill the DataSet with data from the Users table
                        dataAdapter.Fill(dataSet, "Users");

                        // Bind the DataGridView to the DataSet
                        readUserDataDGV.DataSource = dataSet.Tables["Users"];

                        // Subscribe to the CellClick event
                        //readUserDataDGV.CellClick += readUserDataDGV_CellClick;
                    }
                }



            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void readUserDataDGV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = readUserDataDGV.Rows[e.RowIndex];
                selectedUsername = row.Cells["Username"]?.Value?.ToString();
            }
        }

        public void DeleteUser(string username)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    MessageBox.Show("Please select a username to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string connectionString = @"Data Source=DESKTOP-H9MPPVO\SQLEXPRESS;Initial Catalog=UserRegistrationDB;Integrated Security=True;Encrypt=False;";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string deleteQuery = $"DELETE FROM Users WHERE Username = '{username}'";

                    using (SqlCommand deleteCommand = new SqlCommand(deleteQuery, connection))
                    {
                        int rowsAffected = deleteCommand.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("User deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Failed to delete user. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }

                // Refresh the DataGridView after deletion
                InitializeDataGridView("");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void searchUser_TextChanged(object sender, EventArgs e)
        {
            InitializeDataGridView(searchUser.Text);
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(selectedUsername))
            {
                DialogResult result = MessageBox.Show($"Are you sure you want to delete user '{selectedUsername}'?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    DeleteUser(selectedUsername);
                    // Refresh or rebind the DataGridView if needed
                    InitializeDataGridView("");
                    selectedUsername = "";
                }
            }
            else
            {
                MessageBox.Show("Please select a user from the DataGridView before attempting to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

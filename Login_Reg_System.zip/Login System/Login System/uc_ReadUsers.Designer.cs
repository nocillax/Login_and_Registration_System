﻿namespace Login_System
{
    partial class uc_ReadUsers
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_ReadUsers));
            label7 = new Label();
            searchUser = new TextBox();
            label6 = new Label();
            readUserDataDGV = new DataGridView();
            deleteButton = new Button();
            exitbtn = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)readUserDataDGV).BeginInit();
            ((System.ComponentModel.ISupportInitialize)exitbtn).BeginInit();
            SuspendLayout();
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Perpetua Titling MT", 14.25F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point);
            label7.ForeColor = Color.DarkSlateGray;
            label7.Location = new Point(297, 48);
            label7.Name = "label7";
            label7.Size = new Size(235, 23);
            label7.TabIndex = 12;
            label7.Text = "       User Details       ";
            // 
            // searchUser
            // 
            searchUser.BackColor = Color.FromArgb(230, 231, 233);
            searchUser.BorderStyle = BorderStyle.None;
            searchUser.Font = new Font("Nirmala UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            searchUser.Location = new Point(341, 90);
            searchUser.Name = "searchUser";
            searchUser.Size = new Size(216, 20);
            searchUser.TabIndex = 14;
            searchUser.TextChanged += searchUser_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.FlatStyle = FlatStyle.Flat;
            label6.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.DarkSlateGray;
            label6.Location = new Point(252, 91);
            label6.Name = "label6";
            label6.RightToLeft = RightToLeft.No;
            label6.Size = new Size(87, 17);
            label6.TabIndex = 15;
            label6.Text = "Search User :";
            label6.TextAlign = ContentAlignment.MiddleRight;
            // 
            // readUserDataDGV
            // 
            readUserDataDGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            readUserDataDGV.BackgroundColor = Color.Gainsboro;
            readUserDataDGV.BorderStyle = BorderStyle.None;
            readUserDataDGV.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.White;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.NullValue = "-";
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.ControlDark;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            readUserDataDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            readUserDataDGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            readUserDataDGV.GridColor = SystemColors.ControlDarkDark;
            readUserDataDGV.Location = new Point(36, 172);
            readUserDataDGV.Name = "readUserDataDGV";
            readUserDataDGV.ReadOnly = true;
            readUserDataDGV.RowTemplate.Height = 25;
            readUserDataDGV.Size = new Size(756, 322);
            readUserDataDGV.TabIndex = 16;
            // 
            // deleteButton
            // 
            deleteButton.BackColor = Color.DarkSlateGray;
            deleteButton.BackgroundImageLayout = ImageLayout.None;
            deleteButton.Cursor = Cursors.Hand;
            deleteButton.FlatStyle = FlatStyle.Popup;
            deleteButton.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            deleteButton.ForeColor = Color.White;
            deleteButton.Location = new Point(365, 521);
            deleteButton.Name = "deleteButton";
            deleteButton.Size = new Size(74, 31);
            deleteButton.TabIndex = 34;
            deleteButton.Text = "Delete";
            deleteButton.UseVisualStyleBackColor = false;
            deleteButton.Click += deleteButton_Click;
            // 
            // exitbtn
            // 
            exitbtn.Cursor = Cursors.Hand;
            exitbtn.Image = (Image)resources.GetObject("exitbtn.Image");
            exitbtn.Location = new Point(795, 3);
            exitbtn.Name = "exitbtn";
            exitbtn.Size = new Size(25, 24);
            exitbtn.SizeMode = PictureBoxSizeMode.Zoom;
            exitbtn.TabIndex = 35;
            exitbtn.TabStop = false;
            exitbtn.Click += exitbtn_Click;
            // 
            // uc_ReadUsers
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(exitbtn);
            Controls.Add(deleteButton);
            Controls.Add(readUserDataDGV);
            Controls.Add(label6);
            Controls.Add(searchUser);
            Controls.Add(label7);
            Name = "uc_ReadUsers";
            Size = new Size(823, 580);
            ((System.ComponentModel.ISupportInitialize)readUserDataDGV).EndInit();
            ((System.ComponentModel.ISupportInitialize)exitbtn).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label7;
        private TextBox searchUser;
        private Label label6;
        private DataGridView readUserDataDGV;
        private Button deleteButton;
        private PictureBox exitbtn;
    }
}

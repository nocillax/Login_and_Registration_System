﻿namespace Login_System
{
    partial class uc_createUser
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uc_createUser));
            crtUser = new TextBox();
            label7 = new Label();
            dashcrtCreate = new Button();
            dashcrtEmail = new TextBox();
            lbl3 = new Label();
            dashcrtMaritalStatus = new TextBox();
            lbl7 = new Label();
            dashcrtNationality = new TextBox();
            lbl6 = new Label();
            dashcrtReligion = new TextBox();
            dashcrtPhoneNumber = new TextBox();
            lbl4 = new Label();
            dashcrtUniversity = new TextBox();
            label5 = new Label();
            dashcrtPassword = new TextBox();
            label6 = new Label();
            label4 = new Label();
            label2 = new Label();
            dashcrtLastName = new TextBox();
            label3 = new Label();
            dashcrtFirstName = new TextBox();
            label1 = new Label();
            userRoleBox = new ComboBox();
            label8 = new Label();
            exitbtn = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)exitbtn).BeginInit();
            SuspendLayout();
            // 
            // crtUser
            // 
            crtUser.BackColor = Color.FromArgb(230, 231, 233);
            crtUser.BorderStyle = BorderStyle.None;
            crtUser.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            crtUser.Location = new Point(158, 171);
            crtUser.Name = "crtUser";
            crtUser.Size = new Size(216, 20);
            crtUser.TabIndex = 35;
            crtUser.TextChanged += crtUser_TextChanged;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Perpetua Titling MT", 14.25F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point);
            label7.ForeColor = Color.DarkSlateGray;
            label7.Location = new Point(279, 46);
            label7.Name = "label7";
            label7.Size = new Size(262, 23);
            label7.TabIndex = 34;
            label7.Text = "       Create Profile       ";
            // 
            // dashcrtCreate
            // 
            dashcrtCreate.BackColor = Color.DarkSlateGray;
            dashcrtCreate.BackgroundImageLayout = ImageLayout.None;
            dashcrtCreate.Cursor = Cursors.Hand;
            dashcrtCreate.FlatStyle = FlatStyle.Popup;
            dashcrtCreate.Font = new Font("Nirmala UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            dashcrtCreate.ForeColor = Color.White;
            dashcrtCreate.Location = new Point(353, 460);
            dashcrtCreate.Name = "dashcrtCreate";
            dashcrtCreate.Size = new Size(108, 42);
            dashcrtCreate.TabIndex = 33;
            dashcrtCreate.Text = "Create";
            dashcrtCreate.UseVisualStyleBackColor = false;
            dashcrtCreate.Click += dashcrtCreate_Click;
            // 
            // dashcrtEmail
            // 
            dashcrtEmail.BackColor = Color.FromArgb(230, 231, 233);
            dashcrtEmail.BorderStyle = BorderStyle.None;
            dashcrtEmail.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            dashcrtEmail.Location = new Point(535, 221);
            dashcrtEmail.Margin = new Padding(3, 4, 3, 4);
            dashcrtEmail.Name = "dashcrtEmail";
            dashcrtEmail.Size = new Size(216, 20);
            dashcrtEmail.TabIndex = 32;
            dashcrtEmail.TextChanged += dashcrtEmail_TextChanged;
            // 
            // lbl3
            // 
            lbl3.AutoSize = true;
            lbl3.FlatStyle = FlatStyle.Flat;
            lbl3.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbl3.ForeColor = Color.DarkSlateGray;
            lbl3.Location = new Point(483, 220);
            lbl3.Name = "lbl3";
            lbl3.RightToLeft = RightToLeft.No;
            lbl3.Size = new Size(50, 17);
            lbl3.TabIndex = 31;
            lbl3.Text = "Email :";
            lbl3.TextAlign = ContentAlignment.MiddleRight;
            // 
            // dashcrtMaritalStatus
            // 
            dashcrtMaritalStatus.BackColor = Color.FromArgb(230, 231, 233);
            dashcrtMaritalStatus.BorderStyle = BorderStyle.None;
            dashcrtMaritalStatus.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            dashcrtMaritalStatus.Location = new Point(535, 381);
            dashcrtMaritalStatus.Margin = new Padding(3, 4, 3, 4);
            dashcrtMaritalStatus.Name = "dashcrtMaritalStatus";
            dashcrtMaritalStatus.Size = new Size(216, 20);
            dashcrtMaritalStatus.TabIndex = 29;
            dashcrtMaritalStatus.TextChanged += dashcrtMaritalStatus_TextChanged;
            // 
            // lbl7
            // 
            lbl7.AutoSize = true;
            lbl7.FlatStyle = FlatStyle.Flat;
            lbl7.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbl7.ForeColor = Color.DarkSlateGray;
            lbl7.Location = new Point(427, 380);
            lbl7.Name = "lbl7";
            lbl7.RightToLeft = RightToLeft.No;
            lbl7.Size = new Size(102, 17);
            lbl7.TabIndex = 19;
            lbl7.Text = "Marital Status :";
            lbl7.TextAlign = ContentAlignment.MiddleRight;
            // 
            // dashcrtNationality
            // 
            dashcrtNationality.BackColor = Color.FromArgb(230, 231, 233);
            dashcrtNationality.BorderStyle = BorderStyle.None;
            dashcrtNationality.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            dashcrtNationality.Location = new Point(535, 170);
            dashcrtNationality.Margin = new Padding(3, 4, 3, 4);
            dashcrtNationality.Name = "dashcrtNationality";
            dashcrtNationality.Size = new Size(216, 20);
            dashcrtNationality.TabIndex = 28;
            dashcrtNationality.TextChanged += dashcrtNationality_TextChanged;
            // 
            // lbl6
            // 
            lbl6.AutoSize = true;
            lbl6.FlatStyle = FlatStyle.Flat;
            lbl6.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbl6.ForeColor = Color.DarkSlateGray;
            lbl6.Location = new Point(447, 170);
            lbl6.Name = "lbl6";
            lbl6.RightToLeft = RightToLeft.No;
            lbl6.Size = new Size(85, 17);
            lbl6.TabIndex = 20;
            lbl6.Text = "Nationality :";
            lbl6.TextAlign = ContentAlignment.MiddleRight;
            // 
            // dashcrtReligion
            // 
            dashcrtReligion.BackColor = Color.FromArgb(230, 231, 233);
            dashcrtReligion.BorderStyle = BorderStyle.None;
            dashcrtReligion.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            dashcrtReligion.Location = new Point(535, 326);
            dashcrtReligion.Margin = new Padding(3, 4, 3, 4);
            dashcrtReligion.Name = "dashcrtReligion";
            dashcrtReligion.Size = new Size(216, 20);
            dashcrtReligion.TabIndex = 27;
            dashcrtReligion.TextChanged += dashcrtReligion_TextChanged;
            // 
            // dashcrtPhoneNumber
            // 
            dashcrtPhoneNumber.BackColor = Color.FromArgb(230, 231, 233);
            dashcrtPhoneNumber.BorderStyle = BorderStyle.None;
            dashcrtPhoneNumber.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            dashcrtPhoneNumber.Location = new Point(158, 380);
            dashcrtPhoneNumber.Margin = new Padding(3, 4, 3, 4);
            dashcrtPhoneNumber.Name = "dashcrtPhoneNumber";
            dashcrtPhoneNumber.Size = new Size(216, 20);
            dashcrtPhoneNumber.TabIndex = 26;
            dashcrtPhoneNumber.TextChanged += dashcrtPhoneNumber_TextChanged;
            // 
            // lbl4
            // 
            lbl4.AutoSize = true;
            lbl4.FlatStyle = FlatStyle.Flat;
            lbl4.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbl4.ForeColor = Color.DarkSlateGray;
            lbl4.Location = new Point(47, 380);
            lbl4.Name = "lbl4";
            lbl4.RightToLeft = RightToLeft.No;
            lbl4.Size = new Size(109, 17);
            lbl4.TabIndex = 22;
            lbl4.Text = "Phone Number :";
            lbl4.TextAlign = ContentAlignment.MiddleRight;
            // 
            // dashcrtUniversity
            // 
            dashcrtUniversity.BackColor = Color.FromArgb(230, 231, 233);
            dashcrtUniversity.BorderStyle = BorderStyle.None;
            dashcrtUniversity.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            dashcrtUniversity.Location = new Point(535, 271);
            dashcrtUniversity.Margin = new Padding(3, 4, 3, 4);
            dashcrtUniversity.Name = "dashcrtUniversity";
            dashcrtUniversity.Size = new Size(216, 20);
            dashcrtUniversity.TabIndex = 25;
            dashcrtUniversity.TextChanged += dashcrtUniversity_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.FlatStyle = FlatStyle.Flat;
            label5.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.DarkSlateGray;
            label5.Location = new Point(455, 270);
            label5.Name = "label5";
            label5.RightToLeft = RightToLeft.No;
            label5.Size = new Size(78, 17);
            label5.TabIndex = 21;
            label5.Text = "University :";
            label5.TextAlign = ContentAlignment.MiddleRight;
            // 
            // dashcrtPassword
            // 
            dashcrtPassword.BackColor = Color.FromArgb(230, 231, 233);
            dashcrtPassword.BorderStyle = BorderStyle.None;
            dashcrtPassword.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            dashcrtPassword.Location = new Point(158, 221);
            dashcrtPassword.Margin = new Padding(3, 4, 3, 4);
            dashcrtPassword.Name = "dashcrtPassword";
            dashcrtPassword.Size = new Size(216, 20);
            dashcrtPassword.TabIndex = 24;
            dashcrtPassword.TextChanged += dashcrtPassword_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.FlatStyle = FlatStyle.Flat;
            label6.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.DarkSlateGray;
            label6.Location = new Point(80, 171);
            label6.Name = "label6";
            label6.RightToLeft = RightToLeft.No;
            label6.Size = new Size(77, 17);
            label6.TabIndex = 18;
            label6.Text = "Username :";
            label6.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.FlatStyle = FlatStyle.Flat;
            label4.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.DarkSlateGray;
            label4.Location = new Point(466, 325);
            label4.Name = "label4";
            label4.RightToLeft = RightToLeft.No;
            label4.Size = new Size(67, 17);
            label4.TabIndex = 17;
            label4.Text = "Religion :";
            label4.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.DarkSlateGray;
            label2.Location = new Point(83, 220);
            label2.Name = "label2";
            label2.RightToLeft = RightToLeft.No;
            label2.Size = new Size(74, 17);
            label2.TabIndex = 16;
            label2.Text = "Password :";
            label2.TextAlign = ContentAlignment.MiddleRight;
            // 
            // dashcrtLastName
            // 
            dashcrtLastName.BackColor = Color.FromArgb(230, 231, 233);
            dashcrtLastName.BorderStyle = BorderStyle.None;
            dashcrtLastName.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            dashcrtLastName.Location = new Point(158, 325);
            dashcrtLastName.Margin = new Padding(3, 4, 3, 4);
            dashcrtLastName.Name = "dashcrtLastName";
            dashcrtLastName.Size = new Size(216, 20);
            dashcrtLastName.TabIndex = 23;
            dashcrtLastName.TextChanged += dashcrtLastName_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.FlatStyle = FlatStyle.Flat;
            label3.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.DarkSlateGray;
            label3.Location = new Point(75, 325);
            label3.Name = "label3";
            label3.Size = new Size(81, 17);
            label3.TabIndex = 15;
            label3.Text = "Last Name :";
            label3.TextAlign = ContentAlignment.MiddleRight;
            // 
            // dashcrtFirstName
            // 
            dashcrtFirstName.BackColor = Color.FromArgb(230, 231, 233);
            dashcrtFirstName.BorderStyle = BorderStyle.None;
            dashcrtFirstName.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            dashcrtFirstName.Location = new Point(158, 271);
            dashcrtFirstName.Margin = new Padding(3, 4, 3, 4);
            dashcrtFirstName.Name = "dashcrtFirstName";
            dashcrtFirstName.Size = new Size(216, 20);
            dashcrtFirstName.TabIndex = 30;
            dashcrtFirstName.TextChanged += dashcrtFirstName_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.DarkSlateGray;
            label1.Location = new Point(74, 271);
            label1.Name = "label1";
            label1.Size = new Size(83, 17);
            label1.TabIndex = 14;
            label1.Text = "First Name :";
            label1.TextAlign = ContentAlignment.MiddleRight;
            // 
            // userRoleBox
            // 
            userRoleBox.BackColor = Color.Gainsboro;
            userRoleBox.Cursor = Cursors.Hand;
            userRoleBox.FlatStyle = FlatStyle.Flat;
            userRoleBox.ForeColor = SystemColors.WindowText;
            userRoleBox.FormattingEnabled = true;
            userRoleBox.Items.AddRange(new object[] { "Admin", "User" });
            userRoleBox.Location = new Point(385, 75);
            userRoleBox.Name = "userRoleBox";
            userRoleBox.Size = new Size(121, 23);
            userRoleBox.TabIndex = 36;
            userRoleBox.SelectedIndexChanged += userRoleBox_SelectedIndexChanged;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.FlatStyle = FlatStyle.Flat;
            label8.Font = new Font("Nirmala UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.DarkSlateGray;
            label8.Location = new Point(309, 78);
            label8.Name = "label8";
            label8.RightToLeft = RightToLeft.No;
            label8.Size = new Size(74, 17);
            label8.TabIndex = 37;
            label8.Text = "User Role :";
            label8.TextAlign = ContentAlignment.MiddleRight;
            // 
            // exitbtn
            // 
            exitbtn.Cursor = Cursors.Hand;
            exitbtn.Image = (Image)resources.GetObject("exitbtn.Image");
            exitbtn.Location = new Point(795, 3);
            exitbtn.Name = "exitbtn";
            exitbtn.Size = new Size(25, 24);
            exitbtn.SizeMode = PictureBoxSizeMode.Zoom;
            exitbtn.TabIndex = 38;
            exitbtn.TabStop = false;
            exitbtn.Click += exitbtn_Click;
            // 
            // uc_createUser
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(exitbtn);
            Controls.Add(label8);
            Controls.Add(userRoleBox);
            Controls.Add(crtUser);
            Controls.Add(label7);
            Controls.Add(dashcrtCreate);
            Controls.Add(dashcrtEmail);
            Controls.Add(lbl3);
            Controls.Add(dashcrtMaritalStatus);
            Controls.Add(lbl7);
            Controls.Add(dashcrtNationality);
            Controls.Add(lbl6);
            Controls.Add(dashcrtReligion);
            Controls.Add(dashcrtPhoneNumber);
            Controls.Add(lbl4);
            Controls.Add(dashcrtUniversity);
            Controls.Add(label5);
            Controls.Add(dashcrtPassword);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(dashcrtLastName);
            Controls.Add(label3);
            Controls.Add(dashcrtFirstName);
            Controls.Add(label1);
            Name = "uc_createUser";
            Size = new Size(823, 580);
            Load += uc_createUser_Load;
            ((System.ComponentModel.ISupportInitialize)exitbtn).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox crtUser;
        private Label label7;
        private Button dashcrtCreate;
        private TextBox dashcrtEmail;
        private Label lbl3;
        private TextBox dashcrtMaritalStatus;
        private Label lbl7;
        private TextBox dashcrtNationality;
        private Label lbl6;
        private TextBox dashcrtReligion;
        private TextBox dashcrtPhoneNumber;
        private Label lbl4;
        private TextBox dashcrtUniversity;
        private Label label5;
        private TextBox dashcrtPassword;
        private Label label6;
        private Label label4;
        private Label label2;
        private TextBox dashcrtLastName;
        private Label label3;
        private TextBox dashcrtFirstName;
        private Label label1;
        private ComboBox userRoleBox;
        private Label label8;
        private PictureBox exitbtn;
    }
}
